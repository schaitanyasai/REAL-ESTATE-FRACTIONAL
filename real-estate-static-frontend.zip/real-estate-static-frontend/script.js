const dummyProperties = [
  {
    title: "Lakeview Villa",
    location: "Bangalore",
    price: "25 ETH",
    sharesAvailable: 40,
  },
  {
    title: "Urban Heights",
    location: "Mumbai",
    price: "15 ETH",
    sharesAvailable: 20,
  }
];

const propertyList = document.getElementById("propertyList");

dummyProperties.forEach((property) => {
  const card = document.createElement("div");
  card.className = "property-card";
  card.innerHTML = `
    <h3>${property.title}</h3>
    <p><strong>Location:</strong> ${property.location}</p>
    <p><strong>Price:</strong> ${property.price}</p>
    <p><strong>Shares Available:</strong> ${property.sharesAvailable}</p>
    <button>Buy Share</button>
  `;
  propertyList.appendChild(card);
});

document.getElementById("connectWallet").addEventListener("click", async () => {
  if (window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      document.getElementById("walletAddress").textContent = `Connected: ${accounts[0]}`;
    } catch (err) {
      alert("Failed to connect wallet.");
    }
  } else {
    alert("Please install MetaMask.");
  }
});
