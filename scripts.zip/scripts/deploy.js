const hre = require("hardhat");

async function main() {
  // 1. Get the contract factory
  const RealEstateToken = await hre.ethers.getContractFactory("RealEstateToken");
  
  // 2. Deploy the contract (no .deployed() needed)
  const token = await RealEstateToken.deploy();
  
  // 3. Wait for deployment to complete
  await token.waitForDeployment();
  
  // 4. Get the contract address
  console.log("Token deployed to:", await token.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});