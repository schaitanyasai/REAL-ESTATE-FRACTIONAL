module.exports = {
  networks: {
    localhost: {
      url: "http://127.0.0.1:8546", // Changed port
      chainId: 31337,
    }
  }
};